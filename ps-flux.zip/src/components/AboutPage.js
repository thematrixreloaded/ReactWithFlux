import React from "react";

class AboutPage extends React.Component {
  render() {
    return (
      <>
        <h2>About Page</h2>
        <p>This is a React App.</p>
      </>
    );
  }
}

export default AboutPage;
