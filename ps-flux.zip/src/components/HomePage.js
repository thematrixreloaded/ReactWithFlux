import React from "react";

function HomePage() {
  return (
    <div className="jumbotron">
      <h1>Pluralsight Admin Home Page</h1>
      <p>Reat, Flux and React Router for responsive apps.</p>
      <a href="/about">About</a>
    </div>
  );
}

export default HomePage;
